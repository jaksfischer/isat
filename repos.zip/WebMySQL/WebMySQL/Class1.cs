﻿using System;

namespace WebMySQL
{
    public class Class1
    {
    }
}
